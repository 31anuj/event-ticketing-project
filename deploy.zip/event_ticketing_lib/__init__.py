# event_ticketing_lib/__init__.py

def welcome_message():
    return "Welcome to the Event Ticketing Library!"
